<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}
if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}
<html>
<head>
<!-- Assignments Page
	 Author: Michael Fetick, 84270
	 Course: COM287 Internet Programming I, Coleman University
	 Date: 6 October 2013
-->
	<style>
	a {text-decoration: none;}
	</style>
	<title>COM287 Assignments for Tutorial 1</Title>
</head>
<body style="text-align: center;
	  background: wheat url(../splash.jpg) no-repeat fixed center center">
	  
	<h2><sub><small>&nbsp;</small></sub><br /><br />
	<br />COLEMAN UNIVERSITY&nbsp;&nbsp;<br />
	<sup><small>Student: Michael Fetick 84270</small></sup></h2>

	<h2>
	<sub>Instructor: Darlene Garcia</sub><br />
	<big>COM287 Internet Programming I&nbsp;&nbsp;</big>
	</h2>

	<h2>Tutorial 1 &#8212; Developing a Web Page<br />
	<sup><i>( Creating a Product Page for a Startup Company )</i></sup><br />
	<sup><small><i><a href="http://oc.course.com/webdesign/np/xml3/index.cfm?action=home&chapter=1">
		The textbook website's 'Online Companion'</a></i><small></sup></h2>

	<br />
	<br /><table align="center">
	<tr><th>Assignments</th><th>Validation&nbsp;</th></tr>
	<tr><td><a href="tutorial/dave.htm"><b><i>Tutorial - Dave's Devil Sticks&nbsp;</i></b></a></td>
		<td><a href="http://validator.w3.org/check?uri=https://linuxsandbox.coleman.edu/~pm84270/com287/tutorial.01/tutorial/dave.htm">
			<img src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a></td></tr>

	<tr><td><a href="review/basic.htm"><b><i>Review   - Basic&nbsp;</i></b></a></td>
		<td><a href="http://validator.w3.org/check?uri=https://linuxsandbox.coleman.edu/~pm84270/com287/tutorial.01/review/basic.htm">
			<img src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a></td></tr>

	<tr><td><a href="case3/torte.htm"><b><i>Case 3   - Dessert Web&nbsp;</i></b></a></td>
		<td><a href="http://validator.w3.org/check?uri=https://linuxsandbox.coleman.edu/~pm84270/com287/tutorial.01/case3/torte.htm">
			<img src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a></td></tr>
	</table>
	<br />

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

	<h2>Commentary</h2>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}
if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}
if (isset($_POST['quotetext'])):
  // The quote's details have been updated.
  $qid = $_POST['qid'];
  $aid = $_POST['aid'];
  $quotetext = $_POST['quotetext'];

  $sql = "UPDATE fq_quotes SET
          quotetext='$quotetext',
          author_id='$aid'
          WHERE quote_id='$qid'";
		  
  if (mysql_query($sql)) 
  {
    echo '<p><h2 style="color: blue">Your comment has been accepted.</h2></p>';
  } 
  else 
  {
    exit('<p>Error updating quote details: ' .
        mysql_error() . '</p>');
  }
else: // Allow the user to edit the quote
  $qid = $_GET['qid'];
  $quote = @mysql_query(
    "SELECT quotetext, author_id FROM fq_quotes WHERE quote_id =
    '$qid'");
  if (!$quote) 
  {
    exit('<p>Error fetching quote details: ' .
        mysql_error() . '</p>');
  }
  $quote = mysql_fetch_array($quote);
  $quotetext = $quote['quotetext'];
  $quotetext = htmlspecialchars($quotetext);
?>
	<form name="commentsForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<textarea name="quotetext" id="quotetext" 
				  style="background-color: antiquewhite;"
				  rows="2" cols="70" ><?php 
			echo "{$quotetext}\n"?></textarea><br />
		<input type="hidden" name="qid" value="<?php echo $qid; ?>" />
		<input type="submit" value="SUBMIT" />
	</form>
<?php endif; ?>

</body>
</html>
<!-- https://linuxsandbox.coleman.edu/~pm84270/com287/tutorial.01/assignments.01.htm -->

		