/*
    -------------------------------------------------------------------------
    Highlighter (highlighter.js)
    -------------------------------------------------------------------------  
	var elems = document.activeElement.getElementsByClassName("container")
	for (var i=0; i < elems.length; i++) {
		elems[i].visibility = "hidden";
	}
*/
function addEvent(object, evName, fnName, cap) {
   if (object.attachEvent)
       object.attachEvent("on" + evName, fnName);
   else if (object.addEventListener)
       object.addEventListener(evName, fnName, cap);
}

function showHideImage() {
    if (document.getElementById("theImage").style.visibility == "hidden")
        document.getElementById("theImage").style.visibility = "visible";
    else
        document.getElementById("theImage").style.visibility = "hidden";
}

addEvent(window, "load", Highlighter, false);

function highlighter() {
	document.body.background = linear-gradient(gray, black)
}
