document.write("<h2>Excellence</h2>");
document.write("<ul>");
document.write("<li>Best quality and price</li>");
document.write("<li>Authentic in-country experience</li>");
document.write("</ul>");