document.write("Best quality and price<br/>");
document.write("Authentic in-country experice");