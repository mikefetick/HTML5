document.write("<ul>");
document.write("<li>Copiers</li>");
document.write("<li>Fax machines</li>");
document.write("<li>Binding equipment</li>");
document.write("</ul><hr />");
