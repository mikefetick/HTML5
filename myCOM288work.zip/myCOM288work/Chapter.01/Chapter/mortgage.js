document.write("<ul>");
document.write("<li>No money down</li>");
document.write("<li>No income or asset verification</li>");
document.write("<li>Interest only loans</li>");
document.write("</ul>");